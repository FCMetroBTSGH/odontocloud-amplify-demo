import './globals.css';
import type { ReactNode } from 'react';

export const metadata = {
  title: 'PatientPath',
  description: 'PatientPath demo – cloud-native referral workflow'
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="antialiased min-h-screen bg-gray-50 text-gray-900">
        {children}
      </body>
    </html>
  );
}