import Link from 'next/link';

export default function Home() {
  return (
    <main className="p-10">
      <h1 className="text-4xl font-bold mb-4">PatientPath Demo</h1>
      <p className="mb-6">Unified, cloud-native referral platform for modern practices.</p>
      <Link
        href="/referrals/new"
        className="inline-block bg-blue-600 text-white px-6 py-3 rounded hover:bg-blue-700"
      >
        Create Referral
      </Link>
    </main>
  );
}