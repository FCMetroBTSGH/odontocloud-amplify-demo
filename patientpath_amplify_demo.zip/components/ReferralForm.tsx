'use client';
import { useEffect, useState } from 'react';
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
);

type Specialty = {
  id: string;
  name: string;
  procedures: { id: string; name: string }[];
};

export default function ReferralForm() {
  const [catalog, setCatalog] = useState<Specialty[]>([]);
  const [selected, setSelected] = useState<string>('');
  const [checked, setChecked] = useState<{ [id: string]: boolean }>({});

  useEffect(() => {
    (async () => {
      const { data, error } = await supabase
        .from('specialties')
        .select('id,name,procedures(id,name)')
        .order('name');
      if (!error && data) setCatalog(data as any);
    })();
  }, []);

  const procedures =
    catalog.find((s) => s.id === selected)?.procedures ?? [];

  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        alert('Demo submit! Data not persisted.');
      }}
      className="space-y-6"
    >
      <select
        value={selected}
        onChange={(e) => setSelected(e.target.value)}
        className="border p-2 rounded w-full"
      >
        <option value="">Select specialty…</option>
        {catalog.map((s) => (
          <option key={s.id} value={s.id}>
            {s.name}
          </option>
        ))}
      </select>

      {procedures.length > 0 && (
        <div className="grid gap-2">
          {procedures.map((p) => (
            <label key={p.id} className="flex gap-2 items-center">
              <input
                type="checkbox"
                checked={checked[p.id] || false}
                onChange={() =>
                  setChecked((prev) => ({
                    ...prev,
                    [p.id]: !prev[p.id]
                  }))
                }
              />
              {p.name}
            </label>
          ))}
        </div>
      )}

      <textarea
        placeholder="Special instructions…"
        className="border p-2 rounded w-full min-h-[120px]"
      />

      <button
        type="submit"
        className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
      >
        Submit
      </button>
    </form>
  );
}