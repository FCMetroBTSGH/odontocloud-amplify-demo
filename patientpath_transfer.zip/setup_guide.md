# Local & Cloud Setup Guide

## Prerequisites
* Node 18+, pnpm (or npm/yarn)
* Supabase CLI `npm i -g supabase`
* Vercel CLI `npm i -g vercel`

## 1. Fork & clone repo
```
git clone https://github.com/your-org/odontocloud.git
cd odontocloud
pnpm install
```

## 2. Supabase
1. `supabase init`  
2. `supabase db reset --file db/001_init.sql` (local)
3. For cloud, paste the same SQL in the dashboard.

## 3. Environment Variables
Copy `.env.example` to `.env.local` and fill.

## 4. Run dev
```
pnpm dev
```
Visit http://localhost:3000.

## 5. Deploy to Vercel
```
vercel --prod
```

**Remember** to add env vars in Vercel dashboard under **Settings → Environment Variables**.