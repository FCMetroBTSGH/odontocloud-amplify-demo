# CI/CD Pipeline

| Stage | Tool | Purpose |
|-------|------|---------|
| Lint  | ESLint + Prettier | Ensure code style |
| Build | Next.js `next build` | Static check |
| Preview Deploy | Vercel Preview | Pull Request URLs |
| Prod Deploy | Vercel Production | `main` branch push |

Workflow file: `.github/workflows/ci.yml`

Key Steps:
```yaml
- uses: actions/checkout@v4
- uses: pnpm/action-setup@v2
- run: pnpm install
- run: pnpm lint
- run: pnpm build
- uses: amondnet/vercel-action@v25
  with:
    vercel-token: ${{ secrets.VERCEL_TOKEN }}
    vercel-args: '--prod'
```