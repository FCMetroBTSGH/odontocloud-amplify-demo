# PatientPath AI – Succession Anchor Document
_Last updated: 2025-07-01_

## 1. Project Overview
PatientPath AI is a cloud‑native dental platform unifying practice management, AI‑assisted clinical documentation, eRx, claims and patient engagement.  
This MVP prototype is intended **for demo only** (no PHI) and is built with:

| Layer | Stack |
|-------|-------|
| Front‑end | Next.js 14, React, TailwindCSS, shadcn/ui |
| Back‑end | Supabase (PostgreSQL + Auth) |
| AI Layer | OpenAI GPT‑4o mini via REST |
| Hosting | Vercel (web), Supabase cloud (DB) |
| Design | Figma (link in `figma_links.txt`) |

## 2. Repository Structure
```
app/                 # Next.js app router
  └── referrals/
      └── new/       # Dynamic checklist page
components/          # Re‑usable UI blocks
db/                  # SQL migrations & seed scripts
lib/                 # Supabase client helpers
.github/workflows/   # CI – lint, build, preview deploy
tailwind.config.ts
```

## 3. Credentials
Create `.env.local` in the repo root:

```
NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_ANON_KEY=
OPENAI_KEY=
```

_Never commit secrets to Git._

## 4. Active Demo URLs
| Environment | URL | Notes |
|-------------|-----|-------|
| Prod (Vercel) | https://demo.odontocloud.ai | Staging only – no PHI |
| Supabase Project | https://app.supabase.com/project/... | Seeds loaded via `001_init.sql` |

## 5. Key Contacts
| Role | Name | Slack / Email |
|------|------|---------------|
| Founder / Product | Faisal Choudhary | ... |
| Fractional CTO | _TBD_ | ... |

## 6. Immediate Next Tasks
1. Add authentication guard to all pages.
2. Integrate voice‑to‑text (Web Speech → OpenAI Whisper later).
3. Move DB to HIPAA‑eligible RDS + Cognito (see `roadmap.md`).

---

For deeper technical docs, see sibling files:

* `architecture.md` – component & data‑flow diagrams  
* `api_spec.md` – REST payloads  
* `setup_guide.md` – local & cloud install  
* `roadmap.md` – backlog & milestones