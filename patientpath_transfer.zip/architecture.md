# System Architecture

```
[ Browser ]  -->  [ Next.js (Vercel Edge) ]  -->  [ Supabase PostgREST ] --> [ PostgreSQL ]
                       |                              ^
                       v                              |
               [ OpenAI API ] -------------------------
```

* **Next.js** serves the UI and makes client‑side calls to Supabase and OpenAI.
* **Supabase** provides:
  * Row Level Security (RLS) – currently permissive for demo.
  * Realtime subscriptions (future notifications).
* **OpenAI** is called from the browser for AI charting suggestions.  
  * For HIPAA, calls must shift to server‑side with TLS 1.2+ and BAA signed.

### Data Flow
1. Provider selects **“Create Referral.”**
2. Form loads **specialties** and **procedures** from Supabase.
3. On submit, browser invokes `POST /rest/v1/referrals`.
4. Success toast → UI pushes user back to dashboard.

### Security Notes
* Demo runs **without** auth; production must enable Supabase Auth + RLS.
* No patient identifiers other than name are stored in demo DB.