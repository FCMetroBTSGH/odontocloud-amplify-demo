# REST API Specification (Demo)

All endpoints are served by Supabase PostgREST. Replace `PROJECT_REF` with your project ref.

Base URL  
`https://PROJECT_REF.supabase.co/rest/v1`

## Authentication

*Demo*: `apikey` query param with **anon** key.  
*Production*: Use `supabase.auth.session()` bearer JWT.

## Endpoints

### GET /specialties
Return list of specialties and their procedures.

```
GET /specialties?select=id,code,name,procedures(id,name,sort_order)
```

### POST /referrals
Create a new referral.

**Request**
```json
{
  "patient_name": "John Doe",
  "specialty_id": "UUID",
  "procedure_ids": ["UUID","UUID"],
  "special_instructions": "Patient prefers mornings"
}
```

**Response 200**
```json
{
  "id": "UUID",
  "created_at": "2025-07-01T15:00:00Z"
}
```

### GET /referrals?specialty_id=eq.UUID
Filter referrals by specialty.

## Error Codes

| Code | Meaning |
|------|---------|
| 401  | Invalid or missing JWT |
| 500  | Supabase internal error |