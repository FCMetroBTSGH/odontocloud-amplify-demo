# Product Roadmap

## Q3 2025
- [ ] Voice dictation (Web → Whisper server)
- [ ] Auth & RBAC (Supabase RLS)
- [ ] Pilot with 3 practices (no PHI)

## Q4 2025
- [ ] Migrate DB to AWS RDS (HIPAA)
- [ ] Implement ePrescribe (Veradigm Sandbox)
- [ ] BAA signed with AWS + OpenAI

## Q1 2026
- [ ] Claims automation ✨
- [ ] Patient mobile app (React Native)
- [ ] SOC 2 Type II audit