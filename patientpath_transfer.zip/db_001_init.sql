-- 001_init.sql
create extension if not exists "uuid-ossp";

create table specialties (
  id uuid primary key default uuid_generate_v4(),
  code text unique not null,
  name text not null
);

create table procedures (
  id uuid primary key default uuid_generate_v4(),
  specialty_id uuid references specialties(id),
  name text not null,
  sort_order int default 0
);

create table referrals (
  id uuid primary key default uuid_generate_v4(),
  patient_name text,
  specialty_id uuid references specialties(id),
  procedure_ids uuid[] not null,
  special_instructions text,
  created_at timestamptz default now()
);

-- Sample seeds (excerpt)
insert into specialties (code,name) values
  ('PERIO','Periodontics'),
  ('OS','Oral Surgery'),
  ('ENDO','Endodontics'),
  ('ORTHO','Orthodontics'),
  ('PEDO','Pediatric Dentistry'),
  ('PROS','Prosthodontics');

insert into procedures (specialty_id,name,sort_order)
select id,'Comprehensive Periodontal Evaluation',1
from specialties where code='PERIO';