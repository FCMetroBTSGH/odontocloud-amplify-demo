PatientPath – Complete Demo & Documentation Package
Generated on 2025-07-07.

Included:
- patientpath_amplify_demo.zip  : Ready-to-deploy AWS Amplify Next.js demo.
- patientpath_transfer.zip      : Updated succession docs renamed for PatientPath.

Unzip the demo, follow README_AWS.md for deployment.